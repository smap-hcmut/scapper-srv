# TinLikeSub Python SDK — Overview

Async-first Python client for the TinLikeSub Social Listening API
(TikTok / Facebook / YouTube). Most crawl methods enqueue a v2 job
(`POST /api/v2/jobs/{kind}`) and poll until done; a few utility
endpoints stay on v1 direct paths.

- **Package**: `tinlikesub`
- **Python**: 3.10+
- **Transport**: `httpx.AsyncClient`
- **Auth**: API key (`Authorization: Bearer sk-...`), optional HMAC `secret_key`

## Install & init

```python
from tinlikesub import TinLikeSubClient

async with TinLikeSubClient(base_url="https://api.example.com", api_key="sk-...") as client:
    ...
```

Sync wrapper: `TinLikeSubSyncClient` (same surface, blocks on each call).
Note: async generators (e.g. `iter_page_posts`) are **async-only**.

## Exceptions

```python
from tinlikesub import (
    TinLikeSubError, AuthenticationError, ForbiddenError,
    NotFoundError, RateLimitError, PlatformError, APIError,
    JobFailed, JobTimeout,
)
```

`JobFailed` / `JobTimeout` are raised by `client.jobs.run` when the
backing job ends in a non-`done` state or polling exceeds `timeout`.

---

## `client.jobs` — low-level v2 jobs

| Method | Description |
|---|---|
| `enqueue(kind, payload)` | `POST /api/v2/jobs/{kind}` → `{job_id, status, kind}` |
| `fetch(job_id)` | `GET /api/v2/jobs/{job_id}` → status snapshot |
| `run(kind, payload, *, timeout=180, poll_interval=1.0)` | Enqueue + poll until terminal; returns the `result` field |

Use `JobKind` enum for canonical kind strings:

```python
from tinlikesub import JobKind
JobKind.FACEBOOK_PAGE_POSTS.value  # "facebook.page_posts"
```

---

## `client.tiktok`

| Method | Backing | Returns |
|---|---|---|
| `search(keywords, cursor=0, count=20, search_id=None, region=None)` | job `tiktok.search` | `list[dict]` (groups with `posts`) |
| `search_until(keywords, target, page_size=16, region=None, delay=(1,2), max_pages=30)` | loops `search` | per-keyword grouped posts |
| `get_post_detail(urls)` | job `tiktok.item_detail` | `list[dict]` |
| `get_comments(aweme_ids, cursor=0, count=50, threshold=None)` | job `tiktok.comments` | `list[dict]` |
| `get_comment_replies(item_id, comment_id, cursor=0, count=50)` | job `tiktok.replies` | dict with `replies` |
| `get_summary(item_ids)` | v1 `/tiktok/posts/summary` | `list[dict]` |
| `check_cookie()` | v1 `/tiktok/cookie/check` | dict |
| `download(url, filename=None)` | v1 `/tiktok/resources/download` | `bytes` |

---

## `client.facebook`

All crawl methods route through v2 jobs.

| Method | Job kind | Returns |
|---|---|---|
| `get_post_detail(parse_ids)` | `facebook.post_detail` | `list[dict]` |
| `search_graphql(keyword, cursor=None, count=5)` | `facebook.search` | dict with `posts`, `end_cursor`, `has_next` |
| `search_graphql_batch(keywords, count=5)` | parallel `facebook.search` | `list[dict]` |
| `get_comments_graphql(post_id, cursor=None, count=50, sort="hot")` | `facebook.comments` | dict with `comments`, `end_cursor`, `has_next` |
| `get_comments_graphql_batch(post_ids, count=50, sort="hot")` | parallel `facebook.comments` | `list[dict]` |
| `get_replies(comment_id\|comment_feedback_id, expansion_token=None, cursor=None, count=50)` | `facebook.replies` | dict with `replies`, `end_cursor`, `has_next` |
| `get_page_posts(page_id, count=10, cursor=None)` | `facebook.page_posts` | dict with `posts`, `end_cursor`, `has_next`, `pages_fetched` |
| `iter_page_posts(page_id, total, batch_size=60)` | loops `facebook.page_posts` | `AsyncIterator[dict]` (one post at a time) |

### Facebook page_posts — usage

`page_id` must be the **numeric** profile/page id (e.g.
`"100066224874581"`), not a username. Server caps each job at ~50-60
posts; for larger pulls use `iter_page_posts`.

```python
# Single job
result = await client.facebook.get_page_posts(page_id="100066224874581", count=50)
for post in result["posts"]:
    print(post["post_id"], post["message"])

# Auto-paginate
async for post in client.facebook.iter_page_posts("100066224874581", total=500):
    process(post)
```

Response post shape:
```
{
  post_id, story_id, feedback_id, url, message, created_time,
  author: {id, name, url, avatar_url},
  reaction_count, comment_count, share_count,
  attachments: [{type, url, media_url, width, height, caption}, ...] | null,
}
```

`feedback_id` of a post can be passed to `get_comments_graphql`'s
`post_id` argument as the comments anchor.

Notes & caveats:
- Pinned posts and posts shared into the page from others are **skipped** by the handler.
- A post with `reaction_count: 0` minutes after publish is normal; persistent zeros on engaged posts indicate a parser issue (backend auto-dumps for analysis).
- `has_next=True` with `end_cursor=None` should be treated as feed end.
- Username → numeric id resolution is **not** provided; resolve client-side or pass a numeric id.

---

## `client.youtube`

| Method | Endpoint | Notes |
|---|---|---|
| `search(keywords, limit=20, sort_by, upload_date, video_type, duration)` | `POST /v1/youtube/search/batch` | SSR scraping |
| `search_legacy(keyword, channel_ids=None, limit=50)` | `POST /v1/youtube/search` | requires API key |
| `get_videos(keyword=None, page=1, page_size=20)` | `GET /v1/youtube/videos` | stored results |
| `get_video_detail(video_id)` | `GET /v1/youtube/videos/{id}` | watch-page scrape |
| `get_transcript(video_id)` | `GET /v1/youtube/videos/{id}/transcript` | needs CDP YouTube tab |
| `get_comments(video_id, limit=100)` | `POST /v1/youtube/videos/{id}/comments` | SSR |

---

## JobKind enum

```
TIKTOK_SEARCH         = "tiktok.search"
TIKTOK_COMMENTS       = "tiktok.comments"
TIKTOK_REPLIES        = "tiktok.replies"
TIKTOK_ITEM_DETAIL    = "tiktok.item_detail"
TIKTOK_SHOP_VIDEO     = "tiktok.shop_video"
FACEBOOK_SEARCH       = "facebook.search"
FACEBOOK_COMMENTS     = "facebook.comments"
FACEBOOK_REPLIES      = "facebook.replies"
FACEBOOK_POST_DETAIL  = "facebook.post_detail"
FACEBOOK_PAGE_POSTS   = "facebook.page_posts"
YOUTUBE_SEARCH        = "youtube.search"
YOUTUBE_VIDEO_DETAIL  = "youtube.video_detail"
```

---

## Defaults

- Job poll interval: `1.0s`
- Job poll timeout: `180s` (most crawl methods bump to `300s`)
- HTTP timeout: `30s`
- Rate limiting: server-side per account+kind (default 30/min, 500/hr); SDK does not retry on 429 — surfaces as `RateLimitError`.
