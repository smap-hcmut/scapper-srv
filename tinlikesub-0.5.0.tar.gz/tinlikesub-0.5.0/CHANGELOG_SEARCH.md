# TikTok Search SDK — v0.1.6 changelog

## TL;DR
Search cũ đang trả **trùng video** giữa pages và **drift sang related** (TikTok đẩy recommended thay vì kết quả keyword). Đã fix. Có thêm `search_until()` để auto-paginate.

## Breaking? **Không.**
Code cũ vẫn chạy y nguyên. Tất cả param mới đều opt-in.

## API thay đổi

### `tiktok.search()` — thêm 2 param tùy chọn

```python
await client.tiktok.search(
    keywords: list[str],
    cursor: int = 0,
    count: int = 20,
    search_id: str | None = None,   # MỚI
    region: str | None = None,      # MỚI
)
```

- **`search_id`**: lấy từ response page 1 và truyền lại ở page 2, 3… để TikTok giữ đúng phiên search. **Không truyền = TikTok reset session mỗi page → trùng + drift.**
- **`region`**: ISO-2 (`"VN"`, `"US"`, `"JP"`…). Override `region`/`priority_region` query của TikTok. Default `None` = không đụng.

Response giờ có thêm `search_id` cho mỗi keyword group.

### Pattern dùng đúng cho phân trang thủ công

```python
p1 = await c.tiktok.search(["gia dụng"], cursor=0, count=16)
sid = p1[0]["search_id"]

p2 = await c.tiktok.search(
    ["gia dụng"], cursor=p1[0]["cursor"], count=16, search_id=sid,
)
p3 = await c.tiktok.search(
    ["gia dụng"], cursor=p2[0]["cursor"], count=16, search_id=sid,
)
```

Quan trọng: **`page_size` nên ≤ 30** (UI thật dùng 16). Truyền 100+ thì TikTok trả 1 batch rồi đóng session sớm — không phải bug SDK.

### `tiktok.search_until()` — MỚI, auto-paginate

```python
result = await client.tiktok.search_until(
    keywords=["gia dụng"],
    target=160,           # tổng post muốn lấy / keyword
    page_size=16,         # mặc định, mirror UI
    region=None,
    delay=(1.0, 2.0),     # sleep random giữa pages
    max_pages=30,         # cap chống loop vô hạn
)
# result[i] = { "keyword", "search_id", "cursor", "has_more",
#               "pages_fetched", "posts": [...] }
```

Tự pin `search_id`, tự loop, tự stop khi `has_more=False` hoặc đủ `target`.

Khi nào dùng: cần "lấy đủ N video" không quan tâm phân trang.
Khi nào không dùng: cần raw control / progress feedback từng page → dùng `search()`.

## Server fix kèm theo (transparent với SDK user)

- Pin `search_id` qua các page không còn random.
- Dedup `video_id` qua Redis theo `(search_id, keyword)` TTL 30m — bắt phần TikTok đôi khi vẫn trả trùng.
- `is_non_personalized_search=1` để giảm drift (tradeoff: pool hơi nhỏ).

## Cài

```bash
pip install tinlikesub==0.1.6
# hoặc từ wheel: pip install tinlikesub-0.1.6-py3-none-any.whl --force-reinstall
```

## Migration cho code cũ

Không bắt buộc. Nhưng nếu đang gặp duplicate/drift, đổi:

```python
# CŨ — bị trùng/drift
for cursor in [0, 20, 40]:
    res = await c.tiktok.search(["kw"], cursor=cursor, count=20)

# MỚI — pin sid
res = await c.tiktok.search_until(["kw"], target=60, page_size=16)
```
