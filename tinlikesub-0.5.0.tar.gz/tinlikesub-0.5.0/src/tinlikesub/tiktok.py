"""TikTok API resource group.

Crawl-style methods (search, comments, replies, item_detail) go through the
v2 jobs queue (``POST /api/v2/jobs/{kind}`` + poll). Output shape mirrors v1:
list/dict payloads are unwrapped from the handler envelope so callers see the
same data they did before the v2 migration.

Utility endpoints (``check_cookie``, ``download``, ``get_summary``) are not
queued — they remain on v1 direct paths.
"""

from __future__ import annotations

import asyncio
import random
from typing import TYPE_CHECKING, AsyncIterator

from tinlikesub._kinds import JobKind

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


# Crawl jobs paginate server-side; give them generous default timeouts.
_DEFAULT_JOB_TIMEOUT = 300.0


class TikTokResource:
    """TikTok crawl methods (jobs.run) plus a few v1 utility endpoints."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def search(
        self,
        keywords: list[str],
        cursor: int = 0,
        count: int = 20,
        search_id: str | None = None,
        region: str | None = None,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Search TikTok posts by keywords (v2 job: ``tiktok.search``).

        Args:
            keywords: List of search keywords.
            cursor: Pagination cursor (use value from previous response).
            count: Number of posts per keyword per page.
            search_id: Session id from previous page's response. Pass it back
                on subsequent pages to keep the same TikTok search session —
                otherwise results drift to related/recommended videos and
                duplicate across pages.
            region: ISO-2 country code (e.g. "VN", "US", "JP") to bias results.
                Default None keeps server-side default. Note: TikTok also
                weights by IP/cookie, so effect is partial without a matching
                proxy.
            timeout: Max seconds to wait for the job to finish.
        """
        payload: dict = {
            "keywords": keywords,
            "cursor": cursor,
            "count": count,
        }
        if search_id is not None:
            payload["search_id"] = search_id
        if region is not None:
            payload["region"] = region
        result = await self._client.jobs.run(
            JobKind.TIKTOK_SEARCH.value, payload, timeout=timeout,
        )
        return result["posts"]

    async def search_until(
        self,
        keywords: list[str],
        target: int,
        page_size: int = 16,
        region: str | None = None,
        delay: tuple[float, float] = (1.0, 2.0),
        max_pages: int = 30,
    ) -> list[dict]:
        """Auto-paginate TikTok search until each keyword reaches `target` posts.

        Pins `search_id` from page 1 and forwards it on subsequent pages so
        TikTok keeps the same search session (avoids drift to recommended
        videos and cross-page duplicates).

        Args:
            keywords: List of keywords; each paginates independently.
            target: Number of posts to collect per keyword.
            page_size: Posts per request. 16 mirrors TikTok web UI scroll;
                values >30 are typically not honored by TikTok and may close
                the session early.
            region: ISO-2 country code passed on every page (e.g. "VN", "US").
            delay: (min, max) seconds of random sleep between pages, per
                keyword. Reduces rate-limit/anti-bot risk.
            max_pages: Hard cap on pages per keyword to prevent runaway loops
                when TikTok keeps returning has_more=True with stale data.
        """
        state: dict[str, dict] = {
            kw: {"posts": [], "cursor": 0, "sid": None, "done": False, "pages": 0}
            for kw in keywords
        }

        while True:
            active = [
                kw for kw, s in state.items()
                if not s["done"] and len(s["posts"]) < target and s["pages"] < max_pages
            ]
            if not active:
                break

            for kw in active:
                s = state[kw]
                remaining = target - len(s["posts"])
                count = min(page_size, max(remaining, 1))
                page = await self.search(
                    [kw],
                    cursor=s["cursor"],
                    count=count,
                    search_id=s["sid"],
                    region=region,
                )
                grp = page[0] if page else {}
                if s["sid"] is None:
                    s["sid"] = grp.get("search_id")
                s["cursor"] = grp.get("cursor", s["cursor"])
                new_posts = grp.get("posts", []) or []
                s["posts"].extend(new_posts)
                s["pages"] += 1
                if not grp.get("has_more") or not new_posts:
                    s["done"] = True
                    continue
                await asyncio.sleep(random.uniform(*delay))

        return [
            {
                "keyword": kw,
                "search_id": s["sid"],
                "cursor": s["cursor"],
                "has_more": not s["done"],
                "pages_fetched": s["pages"],
                "posts": s["posts"][:target],
            }
            for kw, s in state.items()
        ]

    async def get_post_detail(
        self,
        urls: list[str],
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get detailed info for TikTok posts (v2 job: ``tiktok.item_detail``)."""
        result = await self._client.jobs.run(
            JobKind.TIKTOK_ITEM_DETAIL.value,
            {"urls": urls},
            timeout=timeout,
        )
        return result["items"]

    async def get_summary(self, item_ids: list[str]) -> list[dict]:
        """Get video summaries via customtdk API (v1 — no JobKind)."""
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/summary",
            json={"item_ids": item_ids},
        )

    async def get_comments(
        self,
        aweme_ids: list[str],
        cursor: int = 0,
        count: int = 50,
        threshold: float | None = None,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get comments for TikTok posts (v2 job: ``tiktok.comments``).

        Args:
            aweme_ids: List of video IDs.
            cursor: Pagination cursor.
            count: Number of comments to fetch per post (auto-paginates in pages of 50).
            threshold: If set, auto-fetch replies for comments whose
                ``show_more_score >= threshold`` and ``reply_count > 0``.
        """
        payload: dict = {"aweme_ids": aweme_ids, "cursor": cursor, "count": count}
        if threshold is not None:
            payload["threshold"] = threshold
        result = await self._client.jobs.run(
            JobKind.TIKTOK_COMMENTS.value, payload, timeout=timeout,
        )
        return result["comments"]

    async def get_comment_replies(
        self,
        item_id: str,
        comment_id: str,
        cursor: int = 0,
        count: int = 50,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Get replies for a specific comment (v2 job: ``tiktok.replies``).

        Returns full envelope: ``item_id``, ``comment_id``, ``reply_count``,
        ``has_more``, ``cursor``, ``replies``.
        """
        return await self._client.jobs.run(
            JobKind.TIKTOK_REPLIES.value,
            {
                "item_id": item_id,
                "comment_id": comment_id,
                "cursor": cursor,
                "count": count,
            },
            timeout=timeout,
        )

    async def get_user_posts(
        self,
        sec_uid: str | None = None,
        username: str | None = None,
        count: int = 30,
        cursor: str | None = None,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Fetch posts from a TikTok profile timeline (v2 job: ``tiktok.user_posts``).

        Provide either ``sec_uid`` (preferred — skips one navigate) or
        ``username``. Server resolves ``username`` → ``sec_uid`` by navigating
        ``/@{username}`` and reading the SSR rehydration payload.

        The handler caps each job at ~30 pages × 16 posts. When more is
        requested, response carries ``has_more=True`` plus a ``cursor`` to
        resume; use :meth:`iter_user_posts` to auto-paginate.

        Args:
            sec_uid: TikTok profile secUid.
            username: ``@handle`` (without the ``@``). Used only when
                ``sec_uid`` is missing.
            count: Posts to fetch in this job. [1, 200].
            cursor: Resume cursor (string ms timestamp) from a prior response.

        Returns:
            Dict with ``sec_uid``, ``post_count``, ``pages_fetched``,
            ``has_more``, ``cursor``, ``user`` (only when resolved from
            username), ``posts``.
        """
        if not sec_uid and not username:
            raise ValueError("must provide 'sec_uid' or 'username'")
        payload: dict = {"count": count}
        if sec_uid:
            payload["sec_uid"] = sec_uid
        if username:
            payload["username"] = username
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.TIKTOK_USER_POSTS.value, payload, timeout=timeout,
        )

    async def iter_user_posts(
        self,
        sec_uid: str | None = None,
        username: str | None = None,
        *,
        total: int,
        batch_size: int = 30,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> AsyncIterator[dict]:
        """Async-iterate TikTok profile posts across multiple jobs.

        First call resolves ``username`` → ``sec_uid`` (if needed); subsequent
        calls reuse the resolved ``sec_uid`` to skip the navigate hop.
        """
        if total <= 0:
            return
        if not sec_uid and not username:
            raise ValueError("must provide 'sec_uid' or 'username'")
        batch_size = max(1, min(batch_size, 200))
        cursor: str | None = None
        collected = 0
        resolved_sec_uid = sec_uid
        while collected < total:
            remaining = total - collected
            batch = min(remaining, batch_size)
            result = await self.get_user_posts(
                sec_uid=resolved_sec_uid,
                username=None if resolved_sec_uid else username,
                count=batch,
                cursor=cursor,
                timeout=timeout,
            )
            resolved_sec_uid = result.get("sec_uid") or resolved_sec_uid
            posts = result.get("posts") or []
            if not posts:
                return
            for post in posts:
                yield post
                collected += 1
                if collected >= total:
                    return
            if not result.get("has_more") or not result.get("cursor"):
                return
            cursor = result["cursor"]

    async def check_cookie(self) -> dict:
        """Check if the configured TikTok cookie is still valid (v1 utility)."""
        return await self._client._request("GET", "/api/v1/tiktok/cookie/check")

    async def download(self, url: str, filename: str | None = None) -> bytes:
        """Download a TikTok resource (video, audio, image) via proxy (v1 utility)."""
        params = {"url": url}
        if filename:
            params["filename"] = filename
        return await self._client._request_bytes(
            "GET", "/api/v1/tiktok/resources/download",
            params=params,
        )
