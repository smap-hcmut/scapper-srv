"""Contract tests for TikTokResource — verifies kind + payload + unwrap shape."""

from __future__ import annotations

import pytest

from tests.conftest import assert_job_called


async def test_search_minimal(client):
    client.jobs.run.return_value = {"posts": [{"keyword": "kw", "posts": []}]}
    out = await client.tiktok.search(keywords=["kw"])
    assert_job_called(
        client, "tiktok.search",
        {"keywords": ["kw"], "cursor": 0, "count": 20},
    )
    assert out == [{"keyword": "kw", "posts": []}]  # unwrapped


async def test_search_with_optionals(client):
    client.jobs.run.return_value = {"posts": []}
    await client.tiktok.search(
        keywords=["a", "b"], cursor=10, count=16, search_id="sid", region="VN",
    )
    assert_job_called(
        client, "tiktok.search",
        {
            "keywords": ["a", "b"], "cursor": 10, "count": 16,
            "search_id": "sid", "region": "VN",
        },
    )


async def test_search_omits_none_optionals(client):
    """search_id/region must NOT appear in payload when None — server has no such field."""
    client.jobs.run.return_value = {"posts": []}
    await client.tiktok.search(keywords=["x"])
    _, kwargs = client.jobs.run.await_args
    payload = client.jobs.run.await_args.args[1]
    assert "search_id" not in payload
    assert "region" not in payload


async def test_get_post_detail_unwraps_items(client):
    client.jobs.run.return_value = {"items": [{"id": "1"}, {"id": "2"}]}
    out = await client.tiktok.get_post_detail(urls=["https://tiktok.com/x"])
    assert_job_called(
        client, "tiktok.item_detail",
        {"urls": ["https://tiktok.com/x"]},
    )
    assert out == [{"id": "1"}, {"id": "2"}]


async def test_get_comments_minimal(client):
    client.jobs.run.return_value = {"comments": []}
    out = await client.tiktok.get_comments(aweme_ids=["1", "2"])
    assert_job_called(
        client, "tiktok.comments",
        {"aweme_ids": ["1", "2"], "cursor": 0, "count": 50},
    )
    assert out == []


async def test_get_comments_with_threshold(client):
    client.jobs.run.return_value = {"comments": []}
    await client.tiktok.get_comments(
        aweme_ids=["1"], cursor=50, count=100, threshold=2.5,
    )
    assert_job_called(
        client, "tiktok.comments",
        {"aweme_ids": ["1"], "cursor": 50, "count": 100, "threshold": 2.5},
    )


async def test_get_comment_replies_passthrough(client):
    envelope = {
        "item_id": "i1", "comment_id": "c1", "reply_count": 3,
        "has_more": False, "cursor": 0, "replies": [{"id": "r1"}],
    }
    client.jobs.run.return_value = envelope
    out = await client.tiktok.get_comment_replies(
        item_id="i1", comment_id="c1", cursor=0, count=50,
    )
    assert_job_called(
        client, "tiktok.replies",
        {"item_id": "i1", "comment_id": "c1", "cursor": 0, "count": 50},
    )
    assert out is envelope  # full dict passed through unchanged


async def test_timeout_kwarg_propagates(client):
    client.jobs.run.return_value = {"posts": []}
    await client.tiktok.search(keywords=["x"], timeout=600)
    _, kwargs = client.jobs.run.await_args
    assert kwargs.get("timeout") == 600


async def test_default_timeout_is_300(client):
    client.jobs.run.return_value = {"posts": []}
    await client.tiktok.search(keywords=["x"])
    _, kwargs = client.jobs.run.await_args
    assert kwargs.get("timeout") == 300.0
