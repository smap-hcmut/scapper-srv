"""HTTP-level tests for JobsResource using respx — verifies wire contract.

Covers:
* enqueue() POSTs to /api/v2/jobs/{kind} with body {"payload": {...}}
* fetch() GETs /api/v2/jobs/{job_id}
* run() polls until terminal state
* run() raises JobFailed on failed/cancelled/expired
* run() raises JobTimeout when polling exceeds the deadline
"""

from __future__ import annotations

import httpx
import pytest
import respx

from tinlikesub import JobFailed, JobTimeout, TinLikeSubClient


@pytest.fixture
async def client():
    c = TinLikeSubClient(base_url="http://test.invalid", api_key="sk-test")
    yield c
    await c.close()


@respx.mock
async def test_enqueue_posts_payload_envelope(client):
    route = respx.post("http://test.invalid/api/v2/jobs/tiktok.search").mock(
        return_value=httpx.Response(
            200, json={"job_id": "j1", "status": "queued", "kind": "tiktok.search"},
        ),
    )
    out = await client.jobs.enqueue("tiktok.search", {"keywords": ["x"]})
    assert route.called
    assert route.calls.last.request.read() == b'{"payload": {"keywords": ["x"]}}'
    assert out == {"job_id": "j1", "status": "queued", "kind": "tiktok.search"}


@respx.mock
async def test_fetch_returns_snapshot(client):
    respx.get("http://test.invalid/api/v2/jobs/j1").mock(
        return_value=httpx.Response(200, json={"status": "running"}),
    )
    out = await client.jobs.fetch("j1")
    assert out == {"status": "running"}


@respx.mock
async def test_run_polls_until_done(client):
    respx.post("http://test.invalid/api/v2/jobs/tiktok.search").mock(
        return_value=httpx.Response(200, json={"job_id": "j1", "status": "queued"}),
    )
    respx.get("http://test.invalid/api/v2/jobs/j1").mock(
        side_effect=[
            httpx.Response(200, json={"status": "running"}),
            httpx.Response(200, json={"status": "running"}),
            httpx.Response(200, json={"status": "done", "result": {"posts": [1, 2]}}),
        ],
    )
    out = await client.jobs.run(
        "tiktok.search", {"keywords": ["x"]}, poll_interval=0.01,
    )
    assert out == {"posts": [1, 2]}


@respx.mock
async def test_run_raises_jobfailed_on_failed_status(client):
    respx.post("http://test.invalid/api/v2/jobs/tiktok.search").mock(
        return_value=httpx.Response(200, json={"job_id": "j1", "status": "queued"}),
    )
    respx.get("http://test.invalid/api/v2/jobs/j1").mock(
        return_value=httpx.Response(
            200, json={"status": "failed", "error_code": "BOT_BLOCKED",
                       "error_message": "captcha"},
        ),
    )
    with pytest.raises(JobFailed, match="BOT_BLOCKED"):
        await client.jobs.run(
            "tiktok.search", {"keywords": ["x"]}, poll_interval=0.01,
        )


@respx.mock
async def test_run_raises_jobtimeout_when_no_terminal(client):
    respx.post("http://test.invalid/api/v2/jobs/tiktok.search").mock(
        return_value=httpx.Response(200, json={"job_id": "j1", "status": "queued"}),
    )
    respx.get("http://test.invalid/api/v2/jobs/j1").mock(
        return_value=httpx.Response(200, json={"status": "running"}),
    )
    with pytest.raises(JobTimeout):
        await client.jobs.run(
            "tiktok.search", {"keywords": ["x"]},
            timeout=0.05, poll_interval=0.01,
        )


@respx.mock
@pytest.mark.parametrize("terminal_status", ["cancelled", "expired"])
async def test_run_treats_cancelled_and_expired_as_failure(client, terminal_status):
    respx.post("http://test.invalid/api/v2/jobs/tiktok.search").mock(
        return_value=httpx.Response(200, json={"job_id": "j1", "status": "queued"}),
    )
    respx.get("http://test.invalid/api/v2/jobs/j1").mock(
        return_value=httpx.Response(200, json={"status": terminal_status}),
    )
    with pytest.raises(JobFailed, match=terminal_status):
        await client.jobs.run(
            "tiktok.search", {"keywords": ["x"]}, poll_interval=0.01,
        )
