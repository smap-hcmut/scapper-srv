"""Shared fixtures for SDK contract tests.

The ``client`` fixture builds a real ``TinLikeSubClient`` but replaces
``client.jobs.run`` with an ``AsyncMock`` so resource methods can be exercised
without any HTTP traffic. Tests assert on ``client.jobs.run.await_args`` to
verify the kind + payload contract sent to the server.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from tinlikesub import TinLikeSubClient


@pytest.fixture
def client() -> TinLikeSubClient:
    c = TinLikeSubClient(base_url="http://test.invalid", api_key="sk-test")
    c.jobs.run = AsyncMock()  # type: ignore[method-assign]
    return c


def assert_job_called(
    client: TinLikeSubClient,
    expected_kind: str,
    expected_payload: dict,
) -> None:
    """Verify the last jobs.run() invocation matches the expected contract."""
    client.jobs.run.assert_awaited_once()
    args, kwargs = client.jobs.run.await_args
    kind = args[0] if args else kwargs["kind"]
    payload = args[1] if len(args) > 1 else kwargs["payload"]
    assert kind == expected_kind, f"kind mismatch: {kind!r} != {expected_kind!r}"
    assert payload == expected_payload, (
        f"payload mismatch:\n  got:      {payload!r}\n  expected: {expected_payload!r}"
    )
