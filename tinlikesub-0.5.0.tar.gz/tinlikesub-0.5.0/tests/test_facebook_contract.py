"""Contract tests for FacebookResource — verifies kind + payload + unwrap shape."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from tests.conftest import assert_job_called


async def test_get_post_detail_unwraps_items(client):
    client.jobs.run.return_value = {"items": [{"id": "p1"}]}
    out = await client.facebook.get_post_detail(parse_ids=["p1"])
    assert_job_called(
        client, "facebook.post_detail",
        {"parse_ids": ["p1"]},
    )
    assert out == [{"id": "p1"}]


async def test_search_graphql_passthrough(client):
    envelope = {
        "keyword": "kw", "post_count": 5, "has_next": True,
        "end_cursor": "abc", "posts": [{"post_id": "1"}],
    }
    client.jobs.run.return_value = envelope
    out = await client.facebook.search_graphql(keyword="kw", count=5)
    assert_job_called(
        client, "facebook.search",
        {"keyword": "kw", "count": 5},
    )
    assert out is envelope


async def test_search_graphql_with_cursor(client):
    client.jobs.run.return_value = {"posts": []}
    await client.facebook.search_graphql(keyword="kw", cursor="cur1", count=10)
    assert_job_called(
        client, "facebook.search",
        {"keyword": "kw", "count": 10, "cursor": "cur1"},
    )


async def test_get_comments_graphql_passthrough(client):
    envelope = {
        "post_id": "p1", "total_count": 100, "comment_count": 10,
        "has_next": True, "end_cursor": "c", "comments": [],
    }
    client.jobs.run.return_value = envelope
    out = await client.facebook.get_comments_graphql(
        post_id="p1", count=50, sort="hot",
    )
    assert_job_called(
        client, "facebook.comments",
        {"post_id": "p1", "count": 50, "sort": "hot"},
    )
    assert out is envelope


async def test_get_comments_graphql_with_cursor(client):
    client.jobs.run.return_value = {"comments": []}
    await client.facebook.get_comments_graphql(
        post_id="p1", cursor="c1", count=20, sort="newest",
    )
    assert_job_called(
        client, "facebook.comments",
        {"post_id": "p1", "count": 20, "sort": "newest", "cursor": "c1"},
    )


async def test_get_replies_via_feedback_id(client):
    client.jobs.run.return_value = {"replies": []}
    await client.facebook.get_replies(
        comment_feedback_id="fbid:xyz", count=30,
    )
    assert_job_called(
        client, "facebook.replies",
        {"count": 30, "comment_feedback_id": "fbid:xyz"},
    )


async def test_get_replies_via_comment_id_with_token(client):
    client.jobs.run.return_value = {"replies": []}
    await client.facebook.get_replies(
        comment_id="c1", expansion_token="tok", count=50,
    )
    assert_job_called(
        client, "facebook.replies",
        {"count": 50, "comment_id": "c1", "expansion_token": "tok"},
    )


async def test_get_replies_with_cursor_drops_token(client):
    """When paginating, caller passes cursor; expansion_token is single-use."""
    client.jobs.run.return_value = {"replies": []}
    await client.facebook.get_replies(
        comment_feedback_id="fbid", cursor="page2", count=50,
    )
    payload = client.jobs.run.await_args.args[1]
    assert "expansion_token" not in payload
    assert payload["cursor"] == "page2"


async def test_get_replies_requires_an_id(client):
    with pytest.raises(ValueError, match="comment_id.*comment_feedback_id"):
        await client.facebook.get_replies(count=10)
    client.jobs.run.assert_not_awaited()


async def test_search_graphql_batch_fans_out(client):
    """Batch helper must call jobs.run once per keyword (client-side gather)."""
    client.jobs.run.return_value = {"posts": []}
    out = await client.facebook.search_graphql_batch(
        keywords=["a", "b", "c"], count=5,
    )
    assert client.jobs.run.await_count == 3
    assert len(out) == 3
    kinds = [call.args[0] for call in client.jobs.run.await_args_list]
    assert kinds == ["facebook.search"] * 3
    keywords = [call.args[1]["keyword"] for call in client.jobs.run.await_args_list]
    assert sorted(keywords) == ["a", "b", "c"]


async def test_get_comments_graphql_batch_fans_out(client):
    client.jobs.run.return_value = {"comments": []}
    out = await client.facebook.get_comments_graphql_batch(
        post_ids=["p1", "p2"], count=20, sort="newest",
    )
    assert client.jobs.run.await_count == 2
    assert len(out) == 2
    for call in client.jobs.run.await_args_list:
        assert call.args[0] == "facebook.comments"
        assert call.args[1]["sort"] == "newest"
        assert call.args[1]["count"] == 20


async def test_default_timeout_is_300(client):
    client.jobs.run.return_value = {"posts": []}
    await client.facebook.search_graphql(keyword="x")
    assert client.jobs.run.await_args.kwargs.get("timeout") == 300.0
