"""Facebook API resource group.

All methods route through the v2 jobs queue (``POST /api/v2/jobs/{kind}`` +
poll). Output shape mirrors what callers received in v1 — list payloads are
unwrapped from the ``{"items": [...]}`` envelope; full-dict payloads
(``search_graphql``, ``get_comments_graphql``, ``get_replies``) are returned
as-is from the handler.

Batch helpers (``*_batch``) fan out client-side via ``asyncio.gather`` since
there is no batch JobKind on the server.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from tinlikesub._kinds import JobKind

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


# FB GraphQL pagination is slower (≈5 posts/page); be generous by default.
_DEFAULT_JOB_TIMEOUT = 300.0


class FacebookResource:
    """Facebook crawl methods backed by the v2 jobs queue."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def get_post_detail(
        self,
        parse_ids: list[str],
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get Facebook post details by parse_ids via Graph API (batch).

        Args:
            parse_ids: List of Facebook post parse IDs.
            timeout: Max seconds to wait for the job to finish.
        """
        result = await self._client.jobs.run(
            JobKind.FACEBOOK_POST_DETAIL.value,
            {"parse_ids": parse_ids},
            timeout=timeout,
        )
        return result["items"]

    async def get_comments_graphql(
        self,
        post_id: str,
        cursor: str | None = None,
        count: int = 50,
        sort: str = "hot",
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Get comments via Facebook internal GraphQL API (v2 job: ``facebook.comments``).

        Args:
            post_id: The Facebook post ID.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of comments to fetch.
            sort: Sort order — ``"hot"`` (most relevant) or ``"newest"``.

        Returns:
            Dict with ``post_id``, ``total_count``, ``comment_count``,
            ``has_next``, ``end_cursor``, ``comments``.
        """
        payload: dict = {"post_id": post_id, "count": count, "sort": sort}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_COMMENTS.value, payload, timeout=timeout,
        )

    async def get_comments_graphql_batch(
        self,
        post_ids: list[str],
        count: int = 50,
        sort: str = "hot",
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get comments for multiple posts in parallel (client-side fan-out)."""
        return await asyncio.gather(*(
            self.get_comments_graphql(pid, count=count, sort=sort, timeout=timeout)
            for pid in post_ids
        ))

    async def get_replies(
        self,
        comment_id: str | None = None,
        comment_feedback_id: str | None = None,
        expansion_token: str | None = None,
        cursor: str | None = None,
        count: int = 50,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Get replies for a Facebook comment (v2 job: ``facebook.replies``).

        Pass either ``comment_feedback_id`` (preferred — the literal
        ``feedback.id`` from a parent comment in a prior comments result) or
        ``comment_id`` (the comment's string id; server wraps it as
        ``feedback:<id>`` and base64-encodes).

        ``expansion_token`` is the "show more replies" token shipped inline
        with a parent comment; it is single-use, so use ``cursor`` for page 2+.

        Returns:
            Dict with ``comment_id``, ``comment_feedback_id``, ``total_count``,
            ``reply_count``, ``has_next``, ``end_cursor``, ``replies``.
        """
        if not comment_id and not comment_feedback_id:
            raise ValueError("must provide 'comment_id' or 'comment_feedback_id'")
        payload: dict = {"count": count}
        if comment_id is not None:
            payload["comment_id"] = comment_id
        if comment_feedback_id is not None:
            payload["comment_feedback_id"] = comment_feedback_id
        if expansion_token is not None:
            payload["expansion_token"] = expansion_token
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_REPLIES.value, payload, timeout=timeout,
        )

    async def search_graphql(
        self,
        keyword: str,
        cursor: str | None = None,
        count: int = 5,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Search Facebook posts via internal GraphQL API (v2 job: ``facebook.search``).

        Args:
            keyword: Search query text.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of posts to fetch (auto-paginates server-side).

        Returns:
            Dict with ``keyword``, ``post_count``, ``has_next``, ``end_cursor``,
            ``posts``.
        """
        payload: dict = {"keyword": keyword, "count": count}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_SEARCH.value, payload, timeout=timeout,
        )

    async def search_graphql_batch(
        self,
        keywords: list[str],
        count: int = 5,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Search multiple keywords in parallel (client-side fan-out)."""
        return await asyncio.gather(*(
            self.search_graphql(kw, count=count, timeout=timeout)
            for kw in keywords
        ))
