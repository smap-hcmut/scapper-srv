"""Canonical job kinds — mirror app/models/enums.py::JobKind on the server."""

from __future__ import annotations

from enum import Enum


class JobKind(str, Enum):
    TIKTOK_SEARCH = "tiktok.search"
    TIKTOK_COMMENTS = "tiktok.comments"
    TIKTOK_REPLIES = "tiktok.replies"
    TIKTOK_ITEM_DETAIL = "tiktok.item_detail"
    TIKTOK_SHOP_VIDEO = "tiktok.shop_video"
    FACEBOOK_SEARCH = "facebook.search"
    FACEBOOK_COMMENTS = "facebook.comments"
    FACEBOOK_REPLIES = "facebook.replies"
    FACEBOOK_POST_DETAIL = "facebook.post_detail"
    YOUTUBE_SEARCH = "youtube.search"
    YOUTUBE_VIDEO_DETAIL = "youtube.video_detail"
