"""TinLikeSub Python SDK - Client for the Social Listening API."""

from tinlikesub.client import TinLikeSubClient, TinLikeSubSyncClient
from tinlikesub._exceptions import (
    TinLikeSubError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    PlatformError,
    APIError,
)
from tinlikesub._jobs import JobFailed, JobTimeout
from tinlikesub._kinds import JobKind

__all__ = [
    "TinLikeSubClient",
    "TinLikeSubSyncClient",
    "TinLikeSubError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "PlatformError",
    "APIError",
    "JobFailed",
    "JobTimeout",
    "JobKind",
]

__version__ = "0.3.0"
