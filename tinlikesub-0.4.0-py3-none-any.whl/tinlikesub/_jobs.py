"""Jobs resource — v2 hybrid pattern (enqueue + poll under the hood).

Server endpoints:
    POST /api/v2/jobs/{kind}   -> {job_id, status, kind}
    GET  /api/v2/jobs/{job_id} -> {status, result?, error_code?, error_message?, ...}

Typical use:
    result = await client.jobs.run("tiktok.search", {"keyword": "abc"}, timeout=180)

`run()` blocks until the job is done/failed/expired; raises on failure.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from tinlikesub._exceptions import APIError, PlatformError

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient

DEFAULT_POLL_INTERVAL_S = 1.0
DEFAULT_TIMEOUT_S = 180.0
TERMINAL_STATES = {"done", "failed", "cancelled", "expired"}


class JobTimeout(APIError):
    """Raised when a job does not finish before the polling timeout."""


class JobFailed(PlatformError):
    """Raised when the server reports the job as failed/expired/cancelled."""


class JobsResource:
    def __init__(self, client: "BaseClient"):
        self._client = client

    async def enqueue(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /api/v2/jobs/{kind} → {job_id, status, kind}."""
        return await self._client._request(
            "POST", f"/api/v2/jobs/{kind}", json={"payload": payload}
        )

    async def fetch(self, job_id: str) -> dict[str, Any]:
        """GET /api/v2/jobs/{job_id} → status snapshot (with result if done)."""
        return await self._client._request("GET", f"/api/v2/jobs/{job_id}")

    async def run(
        self,
        kind: str,
        payload: dict[str, Any],
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        poll_interval: float = DEFAULT_POLL_INTERVAL_S,
    ) -> Any:
        """Hybrid: enqueue and poll until terminal. Returns the `result` field.

        Raises:
            JobTimeout: if no terminal state within `timeout` seconds.
            JobFailed:  if status is failed/cancelled/expired.
        """
        enq = await self.enqueue(kind, payload)
        job_id = enq["job_id"]

        deadline = asyncio.get_event_loop().time() + timeout
        delay = poll_interval
        while True:
            snap = await self.fetch(job_id)
            status = snap.get("status")
            if status == "done":
                return snap.get("result")
            if status in TERMINAL_STATES:
                raise JobFailed(
                    f"job {job_id} ended with status={status} "
                    f"code={snap.get('error_code')} msg={snap.get('error_message')}",
                    status_code=502,
                )
            if asyncio.get_event_loop().time() >= deadline:
                raise JobTimeout(
                    f"job {job_id} did not finish within {timeout}s "
                    f"(last_status={status})",
                    status_code=408,
                )
            await asyncio.sleep(delay)
