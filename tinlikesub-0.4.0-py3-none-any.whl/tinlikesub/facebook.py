"""Facebook API resource group.

All methods route through the v2 jobs queue (``POST /api/v2/jobs/{kind}`` +
poll). Output shape mirrors what callers received in v1 — list payloads are
unwrapped from the ``{"items": [...]}`` envelope; full-dict payloads
(``search_graphql``, ``get_comments_graphql``, ``get_replies``) are returned
as-is from the handler.

Batch helpers (``*_batch``) fan out client-side via ``asyncio.gather`` since
there is no batch JobKind on the server.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, AsyncIterator

from tinlikesub._kinds import JobKind

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


# FB GraphQL pagination is slower (≈5 posts/page); be generous by default.
_DEFAULT_JOB_TIMEOUT = 300.0


class FacebookResource:
    """Facebook crawl methods backed by the v2 jobs queue."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def get_post_detail(
        self,
        parse_ids: list[str],
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get Facebook post details by parse_ids via Graph API (batch).

        Args:
            parse_ids: List of Facebook post parse IDs.
            timeout: Max seconds to wait for the job to finish.
        """
        result = await self._client.jobs.run(
            JobKind.FACEBOOK_POST_DETAIL.value,
            {"parse_ids": parse_ids},
            timeout=timeout,
        )
        return result["items"]

    async def get_comments_graphql(
        self,
        post_id: str,
        cursor: str | None = None,
        count: int = 50,
        sort: str = "hot",
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Get comments via Facebook internal GraphQL API (v2 job: ``facebook.comments``).

        Args:
            post_id: The Facebook post ID.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of comments to fetch.
            sort: Sort order — ``"hot"`` (most relevant) or ``"newest"``.

        Returns:
            Dict with ``post_id``, ``total_count``, ``comment_count``,
            ``has_next``, ``end_cursor``, ``comments``.
        """
        payload: dict = {"post_id": post_id, "count": count, "sort": sort}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_COMMENTS.value, payload, timeout=timeout,
        )

    async def get_comments_graphql_batch(
        self,
        post_ids: list[str],
        count: int = 50,
        sort: str = "hot",
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Get comments for multiple posts in parallel (client-side fan-out)."""
        return await asyncio.gather(*(
            self.get_comments_graphql(pid, count=count, sort=sort, timeout=timeout)
            for pid in post_ids
        ))

    async def get_replies(
        self,
        comment_id: str | None = None,
        comment_feedback_id: str | None = None,
        expansion_token: str | None = None,
        cursor: str | None = None,
        count: int = 50,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Get replies for a Facebook comment (v2 job: ``facebook.replies``).

        Pass either ``comment_feedback_id`` (preferred — the literal
        ``feedback.id`` from a parent comment in a prior comments result) or
        ``comment_id`` (the comment's string id; server wraps it as
        ``feedback:<id>`` and base64-encodes).

        ``expansion_token`` is the "show more replies" token shipped inline
        with a parent comment; it is single-use, so use ``cursor`` for page 2+.

        Returns:
            Dict with ``comment_id``, ``comment_feedback_id``, ``total_count``,
            ``reply_count``, ``has_next``, ``end_cursor``, ``replies``.
        """
        if not comment_id and not comment_feedback_id:
            raise ValueError("must provide 'comment_id' or 'comment_feedback_id'")
        payload: dict = {"count": count}
        if comment_id is not None:
            payload["comment_id"] = comment_id
        if comment_feedback_id is not None:
            payload["comment_feedback_id"] = comment_feedback_id
        if expansion_token is not None:
            payload["expansion_token"] = expansion_token
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_REPLIES.value, payload, timeout=timeout,
        )

    async def search_graphql(
        self,
        keyword: str,
        cursor: str | None = None,
        count: int = 5,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Search Facebook posts via internal GraphQL API (v2 job: ``facebook.search``).

        Args:
            keyword: Search query text.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of posts to fetch (auto-paginates server-side).

        Returns:
            Dict with ``keyword``, ``post_count``, ``has_next``, ``end_cursor``,
            ``posts``.
        """
        payload: dict = {"keyword": keyword, "count": count}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_SEARCH.value, payload, timeout=timeout,
        )

    async def search_graphql_batch(
        self,
        keywords: list[str],
        count: int = 5,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> list[dict]:
        """Search multiple keywords in parallel (client-side fan-out)."""
        return await asyncio.gather(*(
            self.search_graphql(kw, count=count, timeout=timeout)
            for kw in keywords
        ))

    async def get_page_posts(
        self,
        page_id: str,
        count: int = 10,
        cursor: str | None = None,
        *,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> dict:
        """Fetch posts from a profile/page timeline (v2 job: ``facebook.page_posts``).

        ``page_id`` MUST be the numeric FB profile/page id (e.g.
        ``"100066224874581"``), not a username/vanity URL. Use
        :meth:`resolve_page_id` first if you only have a username.

        Server-side handler caps each job at ~50-60 posts (``max_pages=60``);
        when more is requested, response carries ``has_next=True`` plus an
        ``end_cursor`` to resume in a follow-up job. Use :meth:`iter_page_posts`
        for auto-pagination.

        Args:
            page_id: Numeric FB profile/page id.
            count: Posts to fetch in this job. Range [1, 200]; values >60 will
                still cap server-side at the per-job limit.
            cursor: ``end_cursor`` from a previous response to resume.

        Returns:
            Dict with ``page_id``, ``post_count``, ``pages_fetched``,
            ``has_next``, ``end_cursor``, ``posts``.
        """
        payload: dict = {"page_id": page_id, "count": count}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client.jobs.run(
            JobKind.FACEBOOK_PAGE_POSTS.value, payload, timeout=timeout,
        )

    async def iter_page_posts(
        self,
        page_id: str,
        total: int,
        *,
        batch_size: int = 60,
        timeout: float = _DEFAULT_JOB_TIMEOUT,
    ) -> AsyncIterator[dict]:
        """Async-iterate posts across multiple jobs until ``total`` collected.

        Splits the work into jobs of ``batch_size`` (recommend ≤60 to match
        the server cap) and chains them via ``end_cursor``. Stops early when
        the feed is exhausted (``has_next=False`` or no cursor).

        Args:
            page_id: Numeric FB profile/page id.
            total: Target number of posts to yield.
            batch_size: Posts requested per job. Capped at 60 (handler limit).

        Yields:
            One post dict at a time (same shape as ``get_page_posts``'s
            ``posts[]`` items).

        Example::

            async for post in client.facebook.iter_page_posts("1006...", total=500):
                process(post)
        """
        if total <= 0:
            return
        batch_size = max(1, min(batch_size, 60))
        cursor: str | None = None
        collected = 0
        while collected < total:
            remaining = total - collected
            batch = min(remaining, batch_size)
            result = await self.get_page_posts(
                page_id, count=batch, cursor=cursor, timeout=timeout,
            )
            posts = result.get("posts") or []
            if not posts:
                return
            for post in posts:
                yield post
                collected += 1
                if collected >= total:
                    return
            if not result.get("has_next") or not result.get("end_cursor"):
                return
            cursor = result["end_cursor"]
