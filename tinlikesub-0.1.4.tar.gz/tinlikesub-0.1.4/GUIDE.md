# TinLikeSub SDK — Hướng dẫn sử dụng & Triển khai

## 1. Cấu trúc folder SDK

Khi mang sang máy khác, chỉ cần copy **folder `sdk/`**:

```
sdk/
├── pyproject.toml              # Package config
├── README.md                   # API reference
├── LICENSE
└── src/
    └── tinlikesub/
        ├── __init__.py         # Public exports
        ├── _base.py            # HTTP client core
        ├── _exceptions.py      # Exception classes
        ├── client.py           # TinLikeSubClient & TinLikeSubSyncClient
        ├── tiktok.py           # client.tiktok.*
        ├── facebook.py         # client.facebook.*
        └── youtube.py          # client.youtube.*
```

## 2. Cài đặt SDK

### Từ folder local (khuyến nghị cho nội bộ)

```bash
# Từ thư mục gốc project
pip install ./sdk

# Hoặc editable mode (dev)
pip install -e ./sdk
```

### Từ file wheel

```bash
# Build wheel
cd sdk
pip install hatchling
python -m build
# File .whl nằm trong sdk/dist/
pip install dist/tinlikesub-0.1.1-py3-none-any.whl
```

### Dependencies

SDK chỉ cần 1 dependency: **httpx** (`>=0.25.0`). Tự cài khi `pip install`.

## 3. Cấu hình SDK

SDK cần 2 tham số:

| Tham số | Mô tả | Ví dụ |
|---------|--------|-------|
| `base_url` | URL của API server | `http://localhost:8104` |
| `api_key` | API key xác thực | `sk-your-secret-key` |

### Khi chạy local (không Docker)

```python
from tinlikesub import TinLikeSubClient

client = TinLikeSubClient(
    base_url="http://localhost:8104",
    api_key="sk-your-secret-key",
)
```

### Khi deploy lên domain

```python
client = TinLikeSubClient(
    base_url="https://api.yourdomain.com",
    api_key="sk-your-secret-key",
)
```

> **Lưu ý:** `api_key` phải khớp với biến `API_KEY` trong file `.env` trên server.
> Nếu server chưa set `API_KEY` (để trống) thì SDK gửi key gì cũng được (dev mode).

## 4. Sử dụng SDK

### Async (khuyến nghị)

```python
import asyncio
from tinlikesub import TinLikeSubClient

async def main():
    async with TinLikeSubClient(
        base_url="https://api.yourdomain.com",
        api_key="sk-xxx",
    ) as client:
        # TikTok
        results = await client.tiktok.search(keywords=["review", "unbox"], cursor=0, count=20)
        details = await client.tiktok.get_post_detail(
            urls=["https://www.tiktok.com/@user/video/123"]
        )
        comments = await client.tiktok.get_comments(aweme_ids=["123"], count=100)

        # Facebook
        gql = await client.facebook.get_comments_graphql(
            post_id="456", count=50, sort="hot"
        )

        # YouTube
        transcript = await client.youtube.get_transcript(video_id="dQw4w9WgXcQ")

asyncio.run(main())
```

### Sync (scripts, notebooks)

```python
from tinlikesub import TinLikeSubSyncClient

with TinLikeSubSyncClient(
    base_url="https://api.yourdomain.com",
    api_key="sk-xxx",
) as client:
    results = client.tiktok.search(keywords=["review"])
    transcript = client.youtube.get_transcript(video_id="dQw4w9WgXcQ")
```

### Xử lý lỗi

```python
from tinlikesub import (
    TinLikeSubClient,
    AuthenticationError,   # 401 — API key sai
    RateLimitError,        # 429 — Quá nhiều request
    PlatformError,         # 502 — Lỗi từ TikTok/Facebook/YouTube
    NotFoundError,         # 404 — Không tìm thấy
    APIError,              # Lỗi khác
)

async with TinLikeSubClient(base_url="...", api_key="...") as client:
    try:
        results = await client.tiktok.search(keywords=["test"])
    except AuthenticationError:
        print("API key không hợp lệ")
    except RateLimitError:
        print("Rate limited, thử lại sau")
    except PlatformError as e:
        print(f"Lỗi platform: {e}")
```

## 5. Triển khai API Server lên domain

### Yêu cầu server

- Docker & Docker Compose
- Chrome chạy với `--remote-debugging-port=9222`
- Domain trỏ về server (A record)

### Các bước deploy

#### 5.1. Copy project lên server

```bash
scp -r . user@server:/opt/tinlikesub
```

#### 5.2. Cấu hình `.env` trên server

```env
# App
APP_NAME=Social Listening API
APP_VERSION=1.0.0
DEBUG=False

# Bắt buộc — set API key cho production
API_KEY=sk-your-secret-key-here

# TikTok
CHROME_CDP_URL=http://host.docker.internal:9222
TIKTOK_COOKIE=msToken=xxx;sessionid=xxx

# Facebook
FACEBOOK_ACCESS_TOKEN=EAAOZCXq...

# YouTube (optional — có thể scrape HTML thay API)
YOUTUBE_API_KEY=

# Database & Redis (giữ nguyên nếu dùng Docker Compose)
DATABASE_URL=postgresql+asyncpg://postgres:postgres@localhost:5432/social_listening
REDIS_URL=redis://localhost:6379/0
```

#### 5.3. Chạy Chrome trên server

```bash
google-chrome --headless --no-sandbox \
  --remote-debugging-port=9222 \
  --remote-debugging-address=0.0.0.0 \
  --remote-allow-origins=* \
  --user-data-dir=/opt/chrome-profile \
  --new-window "https://www.tiktok.com/"
```

> **Quan trọng:** Chrome cần `--remote-debugging-address=0.0.0.0` để Docker container kết nối được.

#### 5.4. Khởi động Docker

```bash
cd /opt/tinlikesub
docker compose up -d --build
```

#### 5.5. Verify

```bash
# Health check
curl http://localhost:8104/health

# Chrome connectivity
curl http://localhost:8104/health/chrome

# API docs
# Mở browser: http://your-domain:8104/docs
```

### 5.6. Reverse proxy (Nginx)

Nếu muốn dùng domain `https://api.yourdomain.com`:

```nginx
server {
    listen 443 ssl;
    server_name api.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8104;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Sau đó SDK config:

```python
client = TinLikeSubClient(
    base_url="https://api.yourdomain.com",
    api_key="sk-your-secret-key-here",
)
```

## 6. API Reference tóm tắt

### TikTok

| Method | Mô tả |
|--------|--------|
| `tiktok.search(keywords, cursor, count)` | Tìm posts theo keywords (paginated) |
| `tiktok.get_post_detail(urls)` | Chi tiết posts (batch, max 5 parallel) |
| `tiktok.get_summary(item_ids)` | Summary videos (batch) |
| `tiktok.get_comments(aweme_ids, cursor, count, threshold)` | Comments với pagination (batch) |
| `tiktok.get_comment_replies(item_id, comment_id, cursor, count)` | Reply comments |
| `tiktok.check_cookie()` | Kiểm tra cookie còn hiệu lực |
| `tiktok.download(url, filename)` | Download video/audio/ảnh |

### Facebook

| Method | Mô tả |
|--------|--------|
| `facebook.search(keyword, page_ids, limit)` | Tìm posts |
| `facebook.get_post_detail(parse_ids)` | Chi tiết posts (Graph API, batch) |
| `facebook.get_comments(post_id, limit)` | Comments (Graph API) |
| `facebook.get_comments_graphql(post_id, cursor, count, sort)` | Comments (GraphQL/CDP) |
| `facebook.get_comments_graphql_batch(post_ids, count, sort)` | Batch comments |

### YouTube

| Method | Mô tả |
|--------|--------|
| `youtube.search(keyword, channel_ids, limit)` | Tìm videos |
| `youtube.get_videos(keyword, page, page_size)` | Lấy videos đã lưu |
| `youtube.get_video_detail(video_id)` | Chi tiết video (HTML scraping) |
| `youtube.get_transcript(video_id)` | Transcript (CDP) |
| `youtube.get_comments(video_id)` | Crawl comments |

## 7. Troubleshooting

| Vấn đề | Nguyên nhân | Giải pháp |
|---------|-------------|-----------|
| `AuthenticationError` | API key sai hoặc thiếu | Kiểm tra `API_KEY` trong `.env` khớp với SDK |
| `Cannot reach Chrome` | Chrome không chạy hoặc thiếu `--remote-debugging-address=0.0.0.0` | Kiểm tra `GET /health/chrome` |
| `PlatformError` | Cookie hết hạn / Token hết hạn | Cập nhật `TIKTOK_COOKIE` hoặc `FACEBOOK_ACCESS_TOKEN` |
| `Transcript button not found` | Video không có phụ đề | Chỉ hoạt động với video có captions |
| Port 8104 bị chiếm | Service khác đang dùng port | Đổi port trong `docker-compose.yml` |
