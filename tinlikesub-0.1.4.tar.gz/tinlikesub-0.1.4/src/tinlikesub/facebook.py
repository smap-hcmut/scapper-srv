"""Facebook API resource group."""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


class FacebookResource:
    """Methods for /api/v1/facebook/* endpoints."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def search(
        self,
        keyword: str,
        page_ids: list[str] | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Search and crawl Facebook posts."""
        payload: dict = {"keyword": keyword, "limit": limit}
        if page_ids is not None:
            payload["page_ids"] = page_ids
        return await self._client._request(
            "POST", "/api/v1/facebook/search", json=payload,
        )

    async def get_post_detail(self, parse_ids: list[str]) -> list[dict]:
        """Get Facebook post details by parse_ids via Graph API (batch).

        Args:
            parse_ids: List of Facebook post parse IDs.
        """
        return await self._client._request(
            "POST", "/api/v1/facebook/posts",
            json={"parse_ids": parse_ids},
        )

    async def get_comments(self, post_id: str, limit: int = 100) -> list[dict]:
        """Get comments for a Facebook post via Graph API."""
        return await self._client._request(
            "GET", f"/api/v1/facebook/posts/{post_id}/comments",
            params={"limit": limit},
        )

    async def get_comments_graphql(
        self,
        post_id: str,
        cursor: str | None = None,
        count: int = 50,
        sort: str = "hot",
    ) -> dict:
        """Get comments via Facebook internal GraphQL API (CDP-based).

        Args:
            post_id: The Facebook post ID.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of comments to fetch.
            sort: Sort order — ``"hot"`` (most relevant) or ``"newest"``.
        """
        params: dict = {"count": count, "sort": sort}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._client._request(
            "GET", f"/api/v1/facebook/posts/{post_id}/comments/graphql",
            params=params,
        )

    async def get_comments_graphql_batch(
        self,
        post_ids: list[str],
        count: int = 50,
        sort: str = "hot",
    ) -> list[dict]:
        """Get comments for multiple posts in parallel via GraphQL API.

        All posts are fetched concurrently on the server side.
        """
        return await self._client._request(
            "POST", "/api/v1/facebook/posts/comments/graphql/batch",
            json={"post_ids": post_ids, "count": count, "sort": sort},
        )

    # ── Search GraphQL (CDP-based) ───────────────────────

    async def search_graphql(
        self,
        keyword: str,
        cursor: str | None = None,
        count: int = 5,
    ) -> dict:
        """Search Facebook posts via internal GraphQL API (CDP-based).

        Args:
            keyword: Search query text.
            cursor: Pagination cursor (from ``end_cursor`` in previous response).
            count: Number of posts to fetch (auto-paginates server-side).
        """
        payload: dict = {"keyword": keyword, "count": count}
        if cursor is not None:
            payload["cursor"] = cursor
        return await self._client._request(
            "POST", "/api/v1/facebook/search/graphql",
            json=payload,
        )

    async def search_graphql_batch(
        self,
        keywords: list[str],
        count: int = 5,
    ) -> list[dict]:
        """Search multiple keywords in parallel via GraphQL API."""
        return await self._client._request(
            "POST", "/api/v1/facebook/search/graphql/batch",
            json={"keywords": keywords, "count": count},
        )
