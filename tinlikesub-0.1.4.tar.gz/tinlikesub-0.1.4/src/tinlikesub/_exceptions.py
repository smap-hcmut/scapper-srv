"""SDK exception hierarchy mapping HTTP errors to typed exceptions."""


class TinLikeSubError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(TinLikeSubError):
    """401 - Missing or invalid API key."""
    pass


class ForbiddenError(TinLikeSubError):
    """403 - API key valid but insufficient permissions."""
    pass


class NotFoundError(TinLikeSubError):
    """404 - Resource not found."""
    pass


class RateLimitError(TinLikeSubError):
    """429 - Too many requests."""

    def __init__(self, message: str, retry_after: int | None = None):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class PlatformError(TinLikeSubError):
    """502 - Upstream platform (TikTok/Facebook/YouTube) error."""
    pass


class APIError(TinLikeSubError):
    """Catch-all for other HTTP errors."""
    pass
