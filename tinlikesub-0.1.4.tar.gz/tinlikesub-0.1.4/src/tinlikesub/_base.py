"""Base HTTP client with session management, error handling, and HMAC signing."""

from __future__ import annotations

import hashlib
import hmac as hmac_mod
import json as json_lib
import time

import httpx

from tinlikesub._exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    PlatformError,
    APIError,
)

_ERROR_MAP = {
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    429: RateLimitError,
    502: PlatformError,
}


class BaseClient:
    """Manages httpx.AsyncClient lifecycle and provides request helpers."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        httpx_client: httpx.AsyncClient | None = None,
        secret_key: str = "",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.secret_key = secret_key
        self.timeout = timeout
        self._external_client = httpx_client is not None
        self._client = httpx_client or httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )

    def _sign(self, method: str, path: str, body: bytes) -> dict[str, str]:
        """Compute HMAC signature headers. Returns empty dict if no secret_key."""
        if not self.secret_key:
            return {}
        timestamp = str(int(time.time()))
        body_hash = hashlib.sha256(body).hexdigest()
        message = f"{timestamp}.{method.upper()}.{path}.{body_hash}"
        signature = hmac_mod.new(
            self.secret_key.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        return {"X-Timestamp": timestamp, "X-Signature": signature}

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
    ) -> dict | list:
        """Send request and return parsed JSON, raising typed exceptions on error."""
        body = json_lib.dumps(json).encode("utf-8") if json is not None else b""
        headers = self._sign(method, path, body)
        if json is not None:
            headers["Content-Type"] = "application/json"
        response = await self._client.request(
            method, path, content=body or None, params=params, headers=headers,
        )
        if response.status_code >= 400:
            detail = ""
            try:
                resp_body = response.json()
                detail = resp_body.get("detail", str(resp_body))
            except Exception:
                detail = response.text
            exc_cls = _ERROR_MAP.get(response.status_code, APIError)
            raise exc_cls(detail, status_code=response.status_code)
        return response.json()

    async def _request_bytes(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
    ) -> bytes:
        """Send request and return raw bytes (for file downloads)."""
        body = json_lib.dumps(json).encode("utf-8") if json is not None else b""
        headers = self._sign(method, path, body)
        if json is not None:
            headers["Content-Type"] = "application/json"
        response = await self._client.request(
            method, path, params=params, content=body or None, headers=headers,
        )
        if response.status_code >= 400:
            detail = response.text
            exc_cls = _ERROR_MAP.get(response.status_code, APIError)
            raise exc_cls(detail, status_code=response.status_code)
        return response.content

    async def close(self):
        """Close the underlying httpx client (only if we own it)."""
        if not self._external_client:
            await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
