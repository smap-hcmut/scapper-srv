"""Main client classes: async and sync wrappers."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx

from tinlikesub._base import BaseClient
from tinlikesub.tiktok import TikTokResource
from tinlikesub.facebook import FacebookResource
from tinlikesub.youtube import YoutubeResource


class TinLikeSubClient(BaseClient):
    """
    Async client for the TinLikeSub Social Listening API.

    Usage::

        async with TinLikeSubClient(base_url="...", api_key="sk-...") as client:
            results = await client.tiktok.search(keywords=["review"])
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        httpx_client: httpx.AsyncClient | None = None,
        secret_key: str = "",
    ):
        super().__init__(base_url, api_key, timeout, httpx_client, secret_key=secret_key)
        self.tiktok = TikTokResource(self)
        self.facebook = FacebookResource(self)
        self.youtube = YoutubeResource(self)


class TinLikeSubSyncClient:
    """
    Synchronous wrapper around TinLikeSubClient.
    Runs async methods in an event loop. Suitable for scripts and notebooks.

    Usage::

        with TinLikeSubSyncClient(base_url="...", api_key="sk-...") as client:
            results = client.tiktok.search(keywords=["review"])
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        secret_key: str = "",
    ):
        self._async_client = TinLikeSubClient(base_url, api_key, timeout, secret_key=secret_key)
        self.tiktok = _SyncResourceProxy(self._async_client.tiktok, self)
        self.facebook = _SyncResourceProxy(self._async_client.facebook, self)
        self.youtube = _SyncResourceProxy(self._async_client.youtube, self)
        self._loop: asyncio.AbstractEventLoop | None = None

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def _run(self, coro):
        return self._get_loop().run_until_complete(coro)

    def close(self):
        self._run(self._async_client.close())
        if self._loop and not self._loop.is_closed():
            self._loop.close()
            self._loop = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class _SyncResourceProxy:
    """Wraps an async resource, making every public method synchronous."""

    def __init__(self, async_resource: Any, sync_client: TinLikeSubSyncClient):
        self._async_resource = async_resource
        self._sync_client = sync_client

    def __getattr__(self, name: str):
        attr = getattr(self._async_resource, name)
        if callable(attr):
            def wrapper(*args, **kwargs):
                return self._sync_client._run(attr(*args, **kwargs))
            wrapper.__name__ = name
            wrapper.__doc__ = attr.__doc__
            return wrapper
        return attr
