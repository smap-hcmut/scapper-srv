"""YouTube API resource group."""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


class YoutubeResource:
    """Methods for /api/v1/youtube/* endpoints."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def search(
        self,
        keywords: list[str],
        limit: int = 20,
        sort_by: str | None = None,
        upload_date: str | None = None,
        video_type: str | None = None,
        duration: str | None = None,
    ) -> list[dict]:
        """Batch search YouTube videos via SSR scraping (no API key needed).

        Args:
            keywords: List of search keywords (parallel).
            limit: Max videos per keyword.
            sort_by: "relevance", "date", "views", or "rating".
            upload_date: "hour", "today", "week", "month", or "year".
            video_type: "video", "channel", or "playlist".
            duration: "short" (<4min), "medium" (4-20min), or "long" (>20min).
        """
        payload: dict = {"keywords": keywords, "limit": limit}
        if sort_by is not None:
            payload["sort_by"] = sort_by
        if upload_date is not None:
            payload["upload_date"] = upload_date
        if video_type is not None:
            payload["video_type"] = video_type
        if duration is not None:
            payload["duration"] = duration
        return await self._client._request(
            "POST", "/api/v1/youtube/search/batch", json=payload,
        )

    async def search_legacy(
        self,
        keyword: str,
        channel_ids: list[str] | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Search YouTube videos via API key (legacy, requires YOUTUBE_API_KEY)."""
        payload: dict = {"keyword": keyword, "limit": limit}
        if channel_ids is not None:
            payload["channel_ids"] = channel_ids
        return await self._client._request(
            "POST", "/api/v1/youtube/search", json=payload,
        )

    async def get_videos(
        self,
        keyword: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> list[dict]:
        """Get stored YouTube videos with optional keyword filter."""
        params: dict = {"page": page, "page_size": page_size}
        if keyword is not None:
            params["keyword"] = keyword
        return await self._client._request(
            "GET", "/api/v1/youtube/videos", params=params,
        )

    async def get_video_detail(self, video_id: str) -> dict:
        """Get YouTube video detail by scraping watch page HTML (no API key needed)."""
        return await self._client._request(
            "GET", f"/api/v1/youtube/videos/{video_id}",
        )

    async def get_transcript(self, video_id: str) -> dict:
        """Get video transcript via YouTube internal API (CDP-based).

        Returns ``full_text`` (concatenated) and ``segments``
        (list with ``start_ms``, ``end_ms``, ``text``, ``start_time_text``).

        Requires Chrome with a YouTube tab logged in on the server.
        """
        return await self._client._request(
            "GET", f"/api/v1/youtube/videos/{video_id}/transcript",
        )

    async def get_comments(self, video_id: str, limit: int = 100) -> dict:
        """Get comments for a YouTube video via SSR scraping (no API key needed)."""
        return await self._client._request(
            "POST", f"/api/v1/youtube/videos/{video_id}/comments",
            params={"limit": limit},
        )
