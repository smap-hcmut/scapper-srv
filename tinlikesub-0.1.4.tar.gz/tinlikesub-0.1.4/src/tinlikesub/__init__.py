"""TinLikeSub Python SDK - Client for the Social Listening API."""

from tinlikesub.client import TinLikeSubClient, TinLikeSubSyncClient
from tinlikesub._exceptions import (
    TinLikeSubError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    PlatformError,
    APIError,
)

__all__ = [
    "TinLikeSubClient",
    "TinLikeSubSyncClient",
    "TinLikeSubError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "PlatformError",
    "APIError",
]

__version__ = "0.1.1"
