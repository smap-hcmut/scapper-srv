# TikTok Search API

## Endpoint

```
POST /api/v1/tiktok/posts/search
```

## Request

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `keywords` | `list[str]` | *(required)* | Danh sach keyword tim kiem |
| `cursor` | `int` | `0` | Vi tri bat dau (dung gia tri `cursor` tu response truoc) |
| `count` | `int` | `20` | So luong ket qua moi keyword moi page |

```json
{
  "keywords": ["do gia dung", "review bep"],
  "cursor": 0,
  "count": 20
}
```

## Response

Mang cac ket qua, moi phan tu tuong ung voi 1 keyword:

```json
[
  {
    "keyword": "do gia dung",
    "cursor": 12,
    "has_more": true,
    "posts": [
      {
        "video_id": "7405448019350424849",
        "url": "https://www.tiktok.com/@user/video/7405448019350424849",
        "description": "Mo ta video...",
        "author": {
          "uid": "123456",
          "username": "user",
          "nickname": "User Name",
          "avatar": "https://..."
        },
        "likes_count": 1500,
        "comments_count": 200,
        "shares_count": 50,
        "views_count": 100000,
        "hashtags": ["giadung", "review"],
        "posted_at": "2024-08-21T05:00:39+00:00",
        "is_shop_video": true
      }
    ]
  }
]
```

### Response fields

| Field | Type | Description |
|-------|------|-------------|
| `keyword` | `str` | Keyword da tim kiem |
| `cursor` | `int` | Cursor cho page tiep theo |
| `has_more` | `bool` | `true` neu con ket qua, `false` neu het |
| `posts` | `list[PostItem]` | Danh sach video tim duoc |

### PostItem fields

| Field | Type | Description |
|-------|------|-------------|
| `video_id` | `str` | ID video |
| `url` | `str` | URL day du cua video |
| `description` | `str` | Mo ta / caption |
| `author` | `AuthorInfo` | Thong tin tac gia |
| `likes_count` | `int` | So luot thich |
| `comments_count` | `int` | So binh luan |
| `shares_count` | `int` | So luot chia se |
| `views_count` | `int` | So luot xem |
| `hashtags` | `list[str]` | Danh sach hashtag |
| `posted_at` | `datetime` | Thoi gian dang |
| `is_shop_video` | `bool` | `true` neu video gan san pham TikTok Shop |

## Pagination

API tra ve `cursor` va `has_more` cho moi keyword. De lay page tiep theo, gui lai request voi `cursor` tu response truoc:

```
Page 1: { "keywords": ["review"], "cursor": 0,  "count": 20 }  ->  cursor=12, has_more=true
Page 2: { "keywords": ["review"], "cursor": 12, "count": 20 }  ->  cursor=24, has_more=true
Page 3: { "keywords": ["review"], "cursor": 24, "count": 20 }  ->  cursor=36, has_more=false  (het)
```

> **Luu y:** Moi keyword co cursor rieng. Khi search nhieu keywords, tat ca dung chung 1 gia tri `cursor` trong request. Neu can phan trang doc lap cho tung keyword, nen goi rieng tung keyword.

## SDK Usage

### Async

```python
import asyncio
from tinlikesub import TinLikeSubClient

async def main():
    async with TinLikeSubClient(
        base_url="http://localhost:8104",
        api_key="sk-xxx",
    ) as client:
        # Page 1
        results = await client.tiktok.search(
            keywords=["do gia dung"],
            cursor=0,
            count=20,
        )

        for r in results:
            print(f"Keyword: {r['keyword']}")
            print(f"  Posts: {len(r['posts'])}")
            print(f"  Has more: {r['has_more']}")
            print(f"  Next cursor: {r['cursor']}")

            for post in r["posts"]:
                shop = " [SHOP]" if post["is_shop_video"] else ""
                print(f"  - {post['video_id']}{shop}: {post['description'][:60]}")

        # Page 2 (neu has_more=true)
        keyword_result = results[0]
        if keyword_result["has_more"]:
            page2 = await client.tiktok.search(
                keywords=["do gia dung"],
                cursor=keyword_result["cursor"],
                count=20,
            )

asyncio.run(main())
```

### Sync

```python
from tinlikesub import TinLikeSubSyncClient

with TinLikeSubSyncClient(
    base_url="http://localhost:8104",
    api_key="sk-xxx",
) as client:
    results = client.tiktok.search(keywords=["review"], cursor=0, count=20)
```

### Auto-paginate (lay tat ca ket qua)

```python
async def search_all(client, keyword: str, count: int = 20, max_pages: int = 10):
    """Lay tat ca ket qua search cho 1 keyword."""
    all_posts = []
    cursor = 0

    for _ in range(max_pages):
        results = await client.tiktok.search(
            keywords=[keyword], cursor=cursor, count=count,
        )
        data = results[0]
        all_posts.extend(data["posts"])

        if not data["has_more"]:
            break
        cursor = data["cursor"]

    return all_posts
```

## TikTok Shop Detection

Field `is_shop_video` cho biet video co gan san pham TikTok Shop hay khong.

Logic detect: Kiem tra `AnchorTypes` trong raw response cua TikTok co chua gia tri `33` (Shop anchor type).

```python
# Loc chi lay video TikTok Shop
results = await client.tiktok.search(keywords=["gia dung"], count=20)
shop_videos = [p for p in results[0]["posts"] if p["is_shop_video"]]
normal_videos = [p for p in results[0]["posts"] if not p["is_shop_video"]]

print(f"Shop videos: {len(shop_videos)}")
print(f"Normal videos: {len(normal_videos)}")
```
