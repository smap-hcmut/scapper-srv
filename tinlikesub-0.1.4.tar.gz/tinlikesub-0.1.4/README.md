# TinLikeSub Python SDK

Python client for the TinLikeSub Social Listening API. Supports TikTok, Facebook, and YouTube.

## Installation

```bash
pip install tinlikesub
```

## Quick Start

### Async (recommended)

```python
import asyncio
from tinlikesub import TinLikeSubClient

async def main():
    async with TinLikeSubClient(base_url="https://your-api.com", api_key="sk-xxx") as client:
        # ── TikTok ──
        results = await client.tiktok.search(keywords=["review", "unbox"], cursor=0, count=20)
        details = await client.tiktok.get_post_detail(urls=["https://www.tiktok.com/@user/video/123"])
        summaries = await client.tiktok.get_summary(item_ids=["123456789"])
        comments = await client.tiktok.get_comments(aweme_ids=["123"], cursor=0, count=50)
        replies = await client.tiktok.get_comment_replies(item_id="123", comment_id="456")
        cookie = await client.tiktok.check_cookie()
        video = await client.tiktok.download(url="https://cdn...", filename="video.mp4")

        # ── Facebook ──
        posts = await client.facebook.search(keyword="brand name", limit=50)
        details = await client.facebook.get_post_detail(parse_ids=["pfbid..."])
        comments = await client.facebook.get_comments(post_id="456", limit=100)
        # GraphQL comments (CDP-based, supports pagination)
        gql = await client.facebook.get_comments_graphql(
            post_id="456", cursor=None, count=50, sort="hot",
        )
        # Batch GraphQL (parallel fetch)
        batch = await client.facebook.get_comments_graphql_batch(
            post_ids=["id1", "id2", "id3"], count=50, sort="newest",
        )

        # ── YouTube ──
        videos = await client.youtube.search(keyword="review", limit=50)
        videos = await client.youtube.get_videos(keyword="review", page=1, page_size=20)
        detail = await client.youtube.get_video_detail(video_id="dQw4w9WgXcQ")
        transcript = await client.youtube.get_transcript(video_id="dQw4w9WgXcQ")
        comments = await client.youtube.get_comments(video_id="abc")

asyncio.run(main())
```

### Sync (scripts & notebooks)

```python
from tinlikesub import TinLikeSubSyncClient

with TinLikeSubSyncClient(base_url="https://your-api.com", api_key="sk-xxx") as client:
    results = client.tiktok.search(keywords=["review"])
    details = client.facebook.get_post_detail(parse_ids=["pfbid..."])
    transcript = client.youtube.get_transcript(video_id="dQw4w9WgXcQ")
```

## Error Handling

```python
from tinlikesub import TinLikeSubClient, AuthenticationError, RateLimitError, PlatformError

async with TinLikeSubClient(base_url="...", api_key="sk-xxx") as client:
    try:
        results = await client.tiktok.search(keywords=["test"])
    except AuthenticationError:
        print("Invalid API key")
    except RateLimitError as e:
        print(f"Rate limited, retry after: {e.retry_after}")
    except PlatformError as e:
        print(f"Platform error: {e.message}")
```

## Exception Hierarchy

| Exception | HTTP Status | Description |
|---|---|---|
| `TinLikeSubError` | - | Base exception |
| `AuthenticationError` | 401 | Missing or invalid API key |
| `ForbiddenError` | 403 | Insufficient permissions |
| `NotFoundError` | 404 | Resource not found |
| `RateLimitError` | 429 | Too many requests |
| `PlatformError` | 502 | Upstream platform error |
| `APIError` | other | Catch-all for other errors |

## API Reference

### Facebook

| Method | Endpoint | Description |
|---|---|---|
| `facebook.search(keyword, page_ids, limit)` | `POST /facebook/search` | Search and crawl posts |
| `facebook.get_post_detail(parse_ids)` | `POST /facebook/posts` | Post details via Graph API (batch) |
| `facebook.get_comments(post_id, limit)` | `GET /facebook/posts/{id}/comments` | Comments via Graph API |
| `facebook.get_comments_graphql(post_id, cursor, count, sort)` | `GET /facebook/posts/{id}/comments/graphql` | Comments via GraphQL (CDP) |
| `facebook.get_comments_graphql_batch(post_ids, count, sort)` | `POST /facebook/posts/comments/graphql/batch` | Batch GraphQL comments |

### YouTube

| Method | Endpoint | Description |
|---|---|---|
| `youtube.search(keyword, channel_ids, limit)` | `POST /youtube/search` | Search and crawl videos |
| `youtube.get_videos(keyword, page, page_size)` | `GET /youtube/videos` | Get stored videos |
| `youtube.get_video_detail(video_id)` | `GET /youtube/videos/{id}` | Video detail via HTML scraping |
| `youtube.get_transcript(video_id)` | `GET /youtube/videos/{id}/transcript` | Transcript via CDP |
| `youtube.get_comments(video_id)` | `POST /youtube/videos/{id}/comments` | Crawl and store comments |

### TikTok

| Method | Endpoint | Description |
|---|---|---|
| `tiktok.search(keywords, cursor, count)` | `POST /tiktok/posts/search` | Search posts by keywords (paginated) |
| `tiktok.get_post_detail(urls)` | `POST /tiktok/posts/detail` | Post details (batch, max 5 parallel) |
| `tiktok.get_summary(item_ids)` | `POST /tiktok/posts/summary` | Video summaries (batch) |
| `tiktok.get_comments(aweme_ids, cursor, count, threshold)` | `POST /tiktok/posts/comments` | Comments with pagination (batch) |
| `tiktok.get_comment_replies(item_id, comment_id, cursor, count)` | `POST /tiktok/posts/comments/replies` | Comment replies |
| `tiktok.check_cookie()` | `GET /tiktok/cookie/check` | Check cookie validity |
| `tiktok.download(url, filename)` | `GET /tiktok/resources/download` | Download resources |

See the full API documentation at your server's `/docs` endpoint (Swagger UI).

## License

MIT
