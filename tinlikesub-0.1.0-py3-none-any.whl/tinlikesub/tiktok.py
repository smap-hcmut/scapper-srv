"""TikTok API resource group."""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tinlikesub._base import BaseClient


class TikTokResource:
    """Methods for /api/v1/tiktok/* endpoints."""

    def __init__(self, client: BaseClient):
        self._client = client

    async def search(self, keywords: list[str]) -> list[dict]:
        """Search TikTok posts by keywords."""
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/search",
            json={"keywords": keywords},
        )

    async def get_post_detail(self, url: str) -> dict:
        """Get detailed info for a single TikTok post."""
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/detail",
            json={"url": url},
        )

    async def get_summary(self, item_id: str) -> dict:
        """Get video summary (title, description, keywords) via customtdk API."""
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/summary",
            json={"item_id": item_id},
        )

    async def get_comments(
        self,
        aweme_id: str,
        cursor: int = 0,
        count: int = 50,
        threshold: float | None = None,
    ) -> dict:
        """Get comments for a TikTok post with cursor pagination.

        Args:
            aweme_id: The video ID.
            cursor: Pagination cursor.
            count: Number of comments to fetch (auto-paginates in pages of 50).
            threshold: If set, auto-fetch replies for comments whose
                ``show_more_score >= threshold`` and ``reply_count > 0``.
        """
        payload: dict = {"aweme_id": aweme_id, "cursor": cursor, "count": count}
        if threshold is not None:
            payload["threshold"] = threshold
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/comments",
            json=payload,
        )

    async def get_comment_replies(
        self,
        item_id: str,
        comment_id: str,
        cursor: int = 0,
        count: int = 50,
    ) -> dict:
        """Get replies for a specific comment."""
        return await self._client._request(
            "POST", "/api/v1/tiktok/posts/comments/replies",
            json={
                "item_id": item_id,
                "comment_id": comment_id,
                "cursor": cursor,
                "count": count,
            },
        )

    async def check_cookie(self) -> dict:
        """Check if the configured TikTok cookie is still valid."""
        return await self._client._request("GET", "/api/v1/tiktok/cookie/check")

    async def download(self, url: str, filename: str | None = None) -> bytes:
        """Download a TikTok resource (video, audio, image) via proxy."""
        params = {"url": url}
        if filename:
            params["filename"] = filename
        return await self._client._request_bytes(
            "GET", "/api/v1/tiktok/resources/download",
            params=params,
        )
